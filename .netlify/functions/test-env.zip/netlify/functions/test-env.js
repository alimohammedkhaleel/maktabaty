// netlify/functions/test-env.js
exports.handler = async (event, context) => {
  return {
    statusCode: 200,
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      hasDatabase: !!process.env.DATABASE_URL,
      envKeys: Object.keys(process.env).filter((k) => k.includes("DATA") || k.includes("NEON") || k.includes("POSTGRES"))
    })
  };
};
